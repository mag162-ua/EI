#ifndef INDEXADOR_HASH_H
#define INDEXADOR_HASH_H

#include <string>
#include <iostream>
#include <list>
#include <ostream>
#include <unordered_map>
#include <unordered_set>
#include <ctime>
#include "indexadorInformacion.h"
#include "tokenizador.h"
#include "stemmer.h"

using namespace std;

class IndexadorHash {

    friend ostream& operator<<(ostream& s, const IndexadorHash& p) {
        s << "Fichero con el listado de palabras de parada: " << p.ficheroStopWords << endl;
        s << "Tokenizador: " << p.tok << endl;
        s << "Directorio donde se almacenara el indice generado: " << p.directorioIndice << endl;
        s << "Stemmer utilizado: " << p.tipoStemmer << endl;
        s << "Informacion de la coleccion indexada: " << p.informacionColeccionDocs << endl;
        s << "Se almacenaran las posiciones de los terminos: " << p.almacenarPosTerm;
        return s;
    }

public:
    // Constructor principal
    IndexadorHash(const string& fichStopWords,
                  const string& delimitadores,
                  const bool& detectComp,
                  const bool& minuscSinAcentos,
                  const string& dirIndice,
                  const int& tStemmer,
                  const bool& almPosTerm);

    // Constructor desde directorio de indexación guardada
    IndexadorHash(const string& directorioIndexacion);

    IndexadorHash(const IndexadorHash&);
    ~IndexadorHash();
    IndexadorHash& operator=(const IndexadorHash&);

    bool Indexar(const string& ficheroDocumentos);
    bool IndexarDirectorio(const string& dirAIndexar);
    bool GuardarIndexacion() const;
    bool RecuperarIndexacion(const string& directorioIndexacion);

    void ImprimirIndexacion() const {
        cout << "Terminos indexados: " << endl;
        for (const auto& [term, info] : indice)
            cout << term << '\t' << info << endl;
        cout << "Documentos indexados: " << endl;
        for (const auto& [nom, info] : indiceDocs)
            cout << nom << '\t' << info << endl;
    }

    bool IndexarPregunta(const string& preg);

    bool DevuelvePregunta(string& preg) const;
    bool DevuelvePregunta(const string& word, InformacionTerminoPregunta& inf) const;
    bool DevuelvePregunta(InformacionPregunta& inf) const;

    void ImprimirIndexacionPregunta() {
        cout << "Pregunta indexada: " << pregunta << endl;
        cout << "Terminos indexados en la pregunta: " << endl;
        for (const auto& [term, info] : indicePregunta)
            cout << term << '\t' << info << endl;
        cout << "Informacion de la pregunta: " << infPregunta << endl;
    }

    void ImprimirPregunta() {
        cout << "Pregunta indexada: " << pregunta << endl;
        cout << "Informacion de la pregunta: " << infPregunta << endl;
    }

    bool Devuelve(const string& word, InformacionTermino& inf) const;
    bool Devuelve(const string& word, const string& nomDoc, InfTermDoc& InfDoc) const;

    bool Existe(const string& word) const;
    bool BorraDoc(const string& nomDoc);

    void VaciarIndiceDocs();
    void VaciarIndicePreg();

    int    NumPalIndexadas() const;
    string DevolverFichPalParada() const;
    void   ListarPalParada() const;
    int    NumPalParada() const;
    string DevolverDelimitadores() const;
    bool   DevolverCasosEspeciales() const;
    bool   DevolverPasarAminuscSinAcentos() const;
    bool   DevolverAlmacenarPosTerm() const;
    string DevolverDirIndice() const;
    int    DevolverTipoStemming() const;

    void ListarInfColeccDocs() const;
    void ListarTerminos() const;
    bool ListarTerminos(const string& nomDoc) const;
    void ListarDocs() const;
    bool ListarDocs(const string& nomDoc) const;

private:
    IndexadorHash();  // Privado: no se permite crear sin inicializar

    unordered_map<string, InformacionTermino>      indice;
    unordered_map<string, InfDoc>                  indiceDocs;
    InfColeccionDocs                               informacionColeccionDocs;

    string                                         pregunta;
    unordered_map<string, InformacionTerminoPregunta> indicePregunta;
    InformacionPregunta                            infPregunta;

    unordered_set<string>                          stopWords;
    string                                         ficheroStopWords;
    Tokenizador                                    tok;
    string                                         directorioIndice;
    int                                            tipoStemmer;
    bool                                           almacenarPosTerm;

    mutable stemmerPorter                          stemmer;
    // mutable: permite usarlo en métodos const (normalizarPalabra)
    // sin necesidad de const_cast

    // Métodos auxiliares privados
    bool normalizarPalabra(string& word) const;
    bool IndexarDoc(const string& nomDoc);

protected:
    int getNumDocs() const { 
        return indiceDocs.size(); 
    }

    // Para obtener avg_ld (promedio de palabras de la colección)
    double getAvg_ld() const { 
        if (indiceDocs.empty()) return 0.0;
        
        double sumaTotalPalabras = 0;
        for (const auto& [nombre, info] : indiceDocs) {
            int numPalSinParada = info.getNumPalSinParada();
            sumaTotalPalabras += numPalSinParada;
        }
        return sumaTotalPalabras / indiceDocs.size();
    } 
    
    // Para obtener ld (longitud de un documento específico)
    int getLongitudDoc(const int& DocId) const {
        for (auto it = indiceDocs.begin(); it != indiceDocs.end(); ++it) {
        if (it->second.getIdDoc() == DocId) {
            return it->second.getNumPalSinParada();
        }
    }
    return 0; // Si no encuentra el ID
    }

    int getPalSinParadaPreg() const {
        return infPregunta.getNumTotalPalSinParada();
    }

    bool DevuelveNombreDocumento(const long int& id, string& nomDoc) const{
        for (const auto& [ruta, inf] : indiceDocs) {
            if (inf.getIdDoc() == id) { 
                nomDoc = ruta;
                return true;
            }
        }
        return false;
    }

    int getNumDocsIndexados() const {
        return indiceDocs.size();
    }

    const unordered_map<string, InformacionTerminoPregunta>& getIndicePregunta() const {
        return indicePregunta;
    }
};

#endif
