#ifndef INDEXADOR_H
#define INDEXADOR_H

#include <string>
#include <list>
#include <vector>
#include <iostream>
#include <ostream>
#include <unordered_map>
#include <unordered_set>
#include <ctime>

using namespace std;

// =============================================================================
// Fecha
// =============================================================================
class Fecha {
public:
    Fecha();
    Fecha(time_t t);
    time_t getTiempo() const;
    void setTiempo(const time_t t);
private:
    time_t tiempo;
};

// =============================================================================
// InfTermDoc  (declaración adelantada necesaria para InformacionTermino)
// =============================================================================
class InfTermDoc {
    friend ostream& operator<<(ostream& s, const InfTermDoc& p);
public:
    InfTermDoc(const InfTermDoc&);
    InfTermDoc();          // Inicializa ft = 0
    ~InfTermDoc();         // Pone ft = 0
    InfTermDoc& operator=(const InfTermDoc&);

    int  getFt() const;
    void setFt(const int ft);
    void addFt();

    // OPTIMIZACIÓN: vector en lugar de list → memoria contigua, sin overhead de punteros
    vector<int>& getPosTerm();
    const vector<int>& getPosTerm_const() const;
    void setPosTerm(const vector<int>& posTerm);
    void addPosTerm(const int pos);

private:
    int ft;            // Frecuencia del término en el documento
    vector<int> posTerm;
    // Solo se almacenará si almacenarPosTerm == true.
    // Lista de posiciones (desde 0) en que aparece el término. Ordenada de menor a mayor.
};

// CORREGIDO: inline para evitar "multiple definition" al incluir el .h en varios .cpp
inline ostream& operator<<(ostream& s, const InfTermDoc& p) {
    s << "ft: " << p.ft;
    bool primero = true;
    for (int pos : p.posTerm) {
        s << "\t" << pos;
    }
    return s;
}

// =============================================================================
// InformacionTermino
// =============================================================================
class InformacionTermino {
    friend ostream& operator<<(ostream& s, const InformacionTermino& p);
public:
    InformacionTermino(const InformacionTermino&);
    InformacionTermino();          // Inicializa ftc = 0
    ~InformacionTermino();         // Pone ftc = 0 y vacía l_docs
    InformacionTermino& operator=(const InformacionTermino&);

    int  getFtc() const;
    void setFtc(const int ftc);
    void addFtc();
    unordered_map<int, InfTermDoc>& getLDocs();
    const unordered_map<int, InfTermDoc>& getLDocs_const() const;
    void addDoc(const int idDoc, const InfTermDoc& infTermDoc);

private:
    int ftc;   // Frecuencia total del término en la colección
    unordered_map<int, InfTermDoc> l_docs;
    // Tabla Hash accedida por id del documento → información de aparición del término
};

inline ostream& operator<<(ostream& s, const InformacionTermino& p) {
    s << "Frecuencia total: " << p.ftc << "\tfd: " << p.l_docs.size();
    for (const auto& [idDoc, itd] : p.l_docs) {
        s << "\tId.Doc: " << idDoc << "\t" << itd;
    }
    return s;
}

// =============================================================================
// InfDoc
// =============================================================================
class InfDoc {
    friend ostream& operator<<(ostream& s, const InfDoc& p);
public:
    InfDoc(int idDoc, int numPal, int numPalSinParada, int numPalDiferentes,
           int tamBytes, const Fecha& fechaModificacion);
    InfDoc(const InfDoc&);
    InfDoc();
    ~InfDoc();
    InfDoc& operator=(const InfDoc&);

    int  getIdDoc() const;
    void setIdDoc(const int idDoc);
    int  getNumPal() const;
    void setNumPal(const int numPal);
    int  getNumPalSinParada() const;
    void setNumPalSinParada(const int numPalSinParada);
    int  getNumPalDiferentes() const;
    void setNumPalDiferentes(const int numPalDiferentes);
    int  getTamBytes() const;
    void setTamBytes(const int tamBytes);
    const Fecha& getFechaModificacion() const;
    void setFechaModificacion(const Fecha& fechaModificacion);

    const unordered_set<string>& getTerminosEnDoc() const;
    void addTerminoEnDoc(const string& termino);

private:
    int idDoc;             // Identificador. El primer doc indexado tiene id=1
    int numPal;            // Nº total de palabras del documento
    int numPalSinParada;   // Nº total de palabras sin stop-words
    int numPalDiferentes;  // Nº total de palabras diferentes (sin stop-words, sin acumular freq)
    int tamBytes;          // Tamaño en bytes del documento
    Fecha fechaModificacion;

    unordered_set<string> terminosEnDoc;
    // Conjunto de términos (ya normalizados) que aparecen en este documento.
    // Permite un BorraDoc() eficiente sin recorrer todo el índice invertido.
};

inline ostream& operator<<(ostream& s, const InfDoc& p) {
    s << "idDoc: " << p.idDoc
      << "\tnumPal: " << p.numPal
      << "\tnumPalSinParada: " << p.numPalSinParada
      << "\tnumPalDiferentes: " << p.numPalDiferentes
      << "\ttamBytes: " << p.tamBytes;
    return s;
}

// =============================================================================
// InfColeccionDocs
// =============================================================================
class InfColeccionDocs {
    friend ostream& operator<<(ostream& s, const InfColeccionDocs& p);
public:
    InfColeccionDocs(int numDocs, int numTotalPal, int numTotalPalSinParada,
                     int numTotalPalDiferentes, int tamBytes);
    InfColeccionDocs(const InfColeccionDocs&);
    InfColeccionDocs();
    ~InfColeccionDocs();
    InfColeccionDocs& operator=(const InfColeccionDocs&);

    int  getNumDocs() const;
    void setNumDocs(const int numDocs);
    int  getNumTotalPal() const;
    void setNumTotalPal(const int numTotalPal);
    int  getNumTotalPalSinParada() const;
    void setNumTotalPalSinParada(const int numTotalPalSinParada);
    int  getNumTotalPalDiferentes() const;
    void setNumTotalPalDiferentes(const int numTotalPalDiferentes);
    int  getTamBytes() const;
    void setTamBytes(const int tamBytes);

private:
    int numDocs;                // Nº total de documentos en la colección
    int numTotalPal;            // Nº total de palabras en la colección
    int numTotalPalSinParada;   // Nº total de palabras sin stop-words
    int numTotalPalDiferentes;  // Nº total de palabras diferentes (sin stop-words, sin acumular)
    int tamBytes;               // Tamaño total en bytes
};

inline ostream& operator<<(ostream& s, const InfColeccionDocs& p) {
    s << "numDocs: " << p.numDocs
      << "\tnumTotalPal: " << p.numTotalPal
      << "\tnumTotalPalSinParada: " << p.numTotalPalSinParada
      << "\tnumTotalPalDiferentes: " << p.numTotalPalDiferentes
      << "\ttamBytes: " << p.tamBytes;
    return s;
}

// =============================================================================
// InformacionTerminoPregunta
// =============================================================================
class InformacionTerminoPregunta {
    friend ostream& operator<<(ostream& s, const InformacionTerminoPregunta& p);
public:
    InformacionTerminoPregunta(const InformacionTerminoPregunta&);
    InformacionTerminoPregunta();
    ~InformacionTerminoPregunta();
    InformacionTerminoPregunta& operator=(const InformacionTerminoPregunta&);

    int  getFt() const;
    void setFt(const int ft);

    // OPTIMIZACIÓN: vector en lugar de list
    const vector<int>& getPosTerm() const;
    vector<int>& getPosTerm();

    void addFt();
    void addPosTerm(const int pos);

private:
    int ft;              // Frecuencia total del término en la pregunta
    vector<int> posTerm;
    // Solo se almacena si almacenarPosTerm == true. Ordenada de menor a mayor posición.
};

inline ostream& operator<<(ostream& s, const InformacionTerminoPregunta& p) {
    s << "ft: " << p.ft;
    for (int pos : p.posTerm) {
        s << "\t" << pos;
    }
    return s;
}

// =============================================================================
// InformacionPregunta
// =============================================================================
class InformacionPregunta {
    friend ostream& operator<<(ostream& s, const InformacionPregunta& p);
public:
    InformacionPregunta(int numTotalPal, int numTotalPalSinParada, int numTotalPalDiferentes);
    InformacionPregunta(const InformacionPregunta&);
    InformacionPregunta();
    ~InformacionPregunta();
    InformacionPregunta& operator=(const InformacionPregunta&);

    int  getNumTotalPal() const;
    void setNumTotalPal(const int num);
    int  getNumTotalPalSinParada() const;
    void setNumTotalPalSinParada(const int num);
    int  getNumTotalPalDiferentes() const;
    void setNumTotalPalDiferentes(const int num);
    bool isEmpty() const;

private:
    int numTotalPal;            // Nº total de palabras en la pregunta
    int numTotalPalSinParada;   // Nº total de palabras sin stop-words
    int numTotalPalDiferentes;  // Nº total de palabras diferentes (sin stop-words, sin acumular)
};

inline ostream& operator<<(ostream& s, const InformacionPregunta& p) {
    s << "numTotalPal: " << p.numTotalPal
      << "\tnumTotalPalSinParada: " << p.numTotalPalSinParada
      << "\tnumTotalPalDiferentes: " << p.numTotalPalDiferentes;
    return s;
}

#endif
