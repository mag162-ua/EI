#include <iostream>
#include <list>
#include <vector>
#include <cctype>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <locale>
#include <algorithm>
#include <fstream>
#include <sys/stat.h>
#include "../include/tokenizador.h"
#include <filesystem>
#include "../include/indexadorInformacion.h"

// =============================================================================
// Fecha
// =============================================================================

Fecha::Fecha() {
    this->tiempo = time(nullptr);
}

Fecha::Fecha(time_t t) {
    this->tiempo = t;
}

time_t Fecha::getTiempo() const {
    return this->tiempo;
}

void Fecha::setTiempo(const time_t t) {
    this->tiempo = t;
}

// =============================================================================
// InformacionTermino
// =============================================================================

InformacionTermino::InformacionTermino() {
    this->ftc = 0;
}

InformacionTermino::InformacionTermino(const InformacionTermino& otra) {
    this->ftc   = otra.ftc;
    this->l_docs = otra.l_docs;
}

InformacionTermino::~InformacionTermino() {
    this->ftc = 0;
    this->l_docs.clear();
}

InformacionTermino& InformacionTermino::operator=(const InformacionTermino& otra) {
    if (this != &otra) {
        this->ftc    = otra.ftc;
        this->l_docs = otra.l_docs;
    }
    return *this;
}

int InformacionTermino::getFtc() const {
    return this->ftc;
}

void InformacionTermino::setFtc(const int ftc) {
    this->ftc = ftc;
}

void InformacionTermino::addFtc() {
    this->ftc++;
}

unordered_map<int, InfTermDoc>& InformacionTermino::getLDocs() {
    return this->l_docs;
}

const unordered_map<int, InfTermDoc>& InformacionTermino::getLDocs_const() const {
    return this->l_docs;
}

void InformacionTermino::addDoc(const int idDoc, const InfTermDoc& infTermDoc) {
    this->l_docs[idDoc] = infTermDoc;
}

// =============================================================================
// InfTermDoc
// =============================================================================

InfTermDoc::InfTermDoc() {
    this->ft = 0;
}

InfTermDoc::InfTermDoc(const InfTermDoc& otra) {
    this->ft      = otra.ft;
    this->posTerm = otra.posTerm;
}

InfTermDoc::~InfTermDoc() {
    this->ft = 0;
    this->posTerm.clear();
}

InfTermDoc& InfTermDoc::operator=(const InfTermDoc& otra) {
    if (this != &otra) {
        this->ft      = otra.ft;
        this->posTerm = otra.posTerm;
    }
    return *this;
}

int InfTermDoc::getFt() const {
    return this->ft;
}

void InfTermDoc::setFt(const int ft) {
    this->ft = ft;
}

void InfTermDoc::addFt() {
    this->ft++;
}

vector<int>& InfTermDoc::getPosTerm() {
    return this->posTerm;
}

const vector<int>& InfTermDoc::getPosTerm_const() const {
    return this->posTerm;
}

void InfTermDoc::setPosTerm(const vector<int>& posTerm) {
    this->posTerm = posTerm;
}

void InfTermDoc::addPosTerm(const int pos) {
    this->posTerm.push_back(pos);
}

// =============================================================================
// InfDoc
// =============================================================================

InfDoc::InfDoc(int idDoc, int numPal, int numPalSinParada, int numPalDiferentes,
               int tamBytes, const Fecha& fechaModificacion) {
    this->idDoc              = idDoc;
    this->numPal             = numPal;
    this->numPalSinParada    = numPalSinParada;
    this->numPalDiferentes   = numPalDiferentes;
    this->tamBytes           = tamBytes;
    this->fechaModificacion  = fechaModificacion;
}

InfDoc::InfDoc() {
    this->idDoc            = 0;
    this->numPal           = 0;
    this->numPalSinParada  = 0;
    this->numPalDiferentes = 0;
    this->tamBytes         = 0;
}

// CORREGIDO: ahora copia fechaModificacion y terminosEnDoc
InfDoc::InfDoc(const InfDoc& otra) {
    this->idDoc             = otra.idDoc;
    this->numPal            = otra.numPal;
    this->numPalSinParada   = otra.numPalSinParada;
    this->numPalDiferentes  = otra.numPalDiferentes;
    this->tamBytes          = otra.tamBytes;
    this->fechaModificacion = otra.fechaModificacion;
    this->terminosEnDoc     = otra.terminosEnDoc;
}

InfDoc::~InfDoc() {
    this->idDoc            = 0;
    this->numPal           = 0;
    this->numPalSinParada  = 0;
    this->numPalDiferentes = 0;
    this->tamBytes         = 0;
    this->terminosEnDoc.clear();
}

// CORREGIDO: ahora copia fechaModificacion y terminosEnDoc
InfDoc& InfDoc::operator=(const InfDoc& otra) {
    if (this != &otra) {
        this->idDoc             = otra.idDoc;
        this->numPal            = otra.numPal;
        this->numPalSinParada   = otra.numPalSinParada;
        this->numPalDiferentes  = otra.numPalDiferentes;
        this->tamBytes          = otra.tamBytes;
        this->fechaModificacion = otra.fechaModificacion;
        this->terminosEnDoc     = otra.terminosEnDoc;
    }
    return *this;
}

int InfDoc::getIdDoc() const                    { return this->idDoc; }
void InfDoc::setIdDoc(const int idDoc)          { this->idDoc = idDoc; }

int InfDoc::getNumPal() const                   { return this->numPal; }
void InfDoc::setNumPal(const int numPal)        { this->numPal = numPal; }

int InfDoc::getNumPalSinParada() const                        { return this->numPalSinParada; }
void InfDoc::setNumPalSinParada(const int numPalSinParada)    { this->numPalSinParada = numPalSinParada; }

int InfDoc::getNumPalDiferentes() const                         { return this->numPalDiferentes; }
void InfDoc::setNumPalDiferentes(const int numPalDiferentes)    { this->numPalDiferentes = numPalDiferentes; }

int InfDoc::getTamBytes() const                 { return this->tamBytes; }
void InfDoc::setTamBytes(const int tamBytes)    { this->tamBytes = tamBytes; }

const Fecha& InfDoc::getFechaModificacion() const                         { return this->fechaModificacion; }
void InfDoc::setFechaModificacion(const Fecha& fechaModificacion)         { this->fechaModificacion = fechaModificacion; }

const unordered_set<string>& InfDoc::getTerminosEnDoc() const             { return this->terminosEnDoc; }
void InfDoc::addTerminoEnDoc(const string& termino)                       { this->terminosEnDoc.insert(termino); }

// =============================================================================
// InfColeccionDocs
// =============================================================================

InfColeccionDocs::InfColeccionDocs(int numDocs, int numTotalPal, int numTotalPalSinParada,
                                   int numTotalPalDiferentes, int tamBytes) {
    this->numDocs                 = numDocs;
    this->numTotalPal             = numTotalPal;
    this->numTotalPalSinParada    = numTotalPalSinParada;
    this->numTotalPalDiferentes   = numTotalPalDiferentes;
    this->tamBytes                = tamBytes;
}

InfColeccionDocs::InfColeccionDocs() {
    this->numDocs               = 0;
    this->numTotalPal           = 0;
    this->numTotalPalSinParada  = 0;
    this->numTotalPalDiferentes = 0;
    this->tamBytes              = 0;
}

InfColeccionDocs::InfColeccionDocs(const InfColeccionDocs& otra) {
    this->numDocs               = otra.numDocs;
    this->numTotalPal           = otra.numTotalPal;
    this->numTotalPalSinParada  = otra.numTotalPalSinParada;
    this->numTotalPalDiferentes = otra.numTotalPalDiferentes;
    this->tamBytes              = otra.tamBytes;
}

InfColeccionDocs::~InfColeccionDocs() {
    this->numDocs               = 0;
    this->numTotalPal           = 0;
    this->numTotalPalSinParada  = 0;
    this->numTotalPalDiferentes = 0;
    this->tamBytes              = 0;
}

InfColeccionDocs& InfColeccionDocs::operator=(const InfColeccionDocs& otra) {
    if (this != &otra) {
        this->numDocs               = otra.numDocs;
        this->numTotalPal           = otra.numTotalPal;
        this->numTotalPalSinParada  = otra.numTotalPalSinParada;
        this->numTotalPalDiferentes = otra.numTotalPalDiferentes;
        this->tamBytes              = otra.tamBytes;
    }
    return *this;
}

int InfColeccionDocs::getNumDocs() const                        { return this->numDocs; }
void InfColeccionDocs::setNumDocs(const int numDocs)            { this->numDocs = numDocs; }

int InfColeccionDocs::getNumTotalPal() const                    { return this->numTotalPal; }
void InfColeccionDocs::setNumTotalPal(const int n)              { this->numTotalPal = n; }

int InfColeccionDocs::getNumTotalPalSinParada() const           { return this->numTotalPalSinParada; }
void InfColeccionDocs::setNumTotalPalSinParada(const int n)     { this->numTotalPalSinParada = n; }

int InfColeccionDocs::getNumTotalPalDiferentes() const          { return this->numTotalPalDiferentes; }
void InfColeccionDocs::setNumTotalPalDiferentes(const int n)    { this->numTotalPalDiferentes = n; }

int InfColeccionDocs::getTamBytes() const                       { return this->tamBytes; }
void InfColeccionDocs::setTamBytes(const int tamBytes)          { this->tamBytes = tamBytes; }

// =============================================================================
// InformacionTerminoPregunta
// =============================================================================

InformacionTerminoPregunta::InformacionTerminoPregunta() {
    this->ft = 0;
}

InformacionTerminoPregunta::InformacionTerminoPregunta(const InformacionTerminoPregunta& otra) {
    this->ft      = otra.ft;
    this->posTerm = otra.posTerm;
}

InformacionTerminoPregunta::~InformacionTerminoPregunta() {
    this->ft = 0;
    this->posTerm.clear();
}

InformacionTerminoPregunta& InformacionTerminoPregunta::operator=(const InformacionTerminoPregunta& otra) {
    if (this != &otra) {
        this->ft      = otra.ft;
        this->posTerm = otra.posTerm;
    }
    return *this;
}

int InformacionTerminoPregunta::getFt() const           { return this->ft; }
void InformacionTerminoPregunta::setFt(const int ft)    { this->ft = ft; }

const vector<int>& InformacionTerminoPregunta::getPosTerm() const  { return this->posTerm; }
vector<int>& InformacionTerminoPregunta::getPosTerm()              { return this->posTerm; }

void InformacionTerminoPregunta::addFt()                { this->ft++; }
void InformacionTerminoPregunta::addPosTerm(const int pos) { this->posTerm.push_back(pos); }

// =============================================================================
// InformacionPregunta
// =============================================================================

InformacionPregunta::InformacionPregunta(int numTotalPal, int numTotalPalSinParada,
                                         int numTotalPalDiferentes) {
    this->numTotalPal           = numTotalPal;
    this->numTotalPalSinParada  = numTotalPalSinParada;
    this->numTotalPalDiferentes = numTotalPalDiferentes;
}

InformacionPregunta::InformacionPregunta(const InformacionPregunta& otra) {
    this->numTotalPal           = otra.numTotalPal;
    this->numTotalPalSinParada  = otra.numTotalPalSinParada;
    this->numTotalPalDiferentes = otra.numTotalPalDiferentes;
}

InformacionPregunta::InformacionPregunta() {
    this->numTotalPal           = 0;
    this->numTotalPalSinParada  = 0;
    this->numTotalPalDiferentes = 0;
}

InformacionPregunta::~InformacionPregunta() {
    this->numTotalPal           = 0;
    this->numTotalPalSinParada  = 0;
    this->numTotalPalDiferentes = 0;
}

InformacionPregunta& InformacionPregunta::operator=(const InformacionPregunta& otra) {
    if (this != &otra) {
        this->numTotalPal           = otra.numTotalPal;
        this->numTotalPalSinParada  = otra.numTotalPalSinParada;
        this->numTotalPalDiferentes = otra.numTotalPalDiferentes;
    }
    return *this;
}

int  InformacionPregunta::getNumTotalPal() const                 { return this->numTotalPal; }
void InformacionPregunta::setNumTotalPal(const int num)          { this->numTotalPal = num; }

int  InformacionPregunta::getNumTotalPalSinParada() const        { return this->numTotalPalSinParada; }
void InformacionPregunta::setNumTotalPalSinParada(const int num) { this->numTotalPalSinParada = num; }

int  InformacionPregunta::getNumTotalPalDiferentes() const        { return this->numTotalPalDiferentes; }
void InformacionPregunta::setNumTotalPalDiferentes(const int num) { this->numTotalPalDiferentes = num; }

bool InformacionPregunta::isEmpty() const {
    return this->numTotalPal == 0;
}
