#include <iostream>
#include <queue>
#include <cmath>
#include <algorithm>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
 
#include "../include/buscador.h"

using namespace std;


 
ResultadoRI::ResultadoRI(const  double&  kvSimilitud,  const  long  int&  kidDoc, const int& np) 
{ 
  vSimilitud = kvSimilitud; 
  idDoc = kidDoc; 
  numPregunta = np; 
} 
 
double ResultadoRI::VSimilitud() const 
{ 
  return vSimilitud; 
} 
 
long int ResultadoRI::IdDoc() const 
{ 
  return idDoc; 
} 

int ResultadoRI::NumPregunta() const 
{ 
  return numPregunta; 
}
 
bool ResultadoRI::operator< (const ResultadoRI& lhs) const 
{ 
  if(numPregunta == lhs.numPregunta) 
    return (vSimilitud < lhs.vSimilitud); 
  else 
    return (numPregunta > lhs.numPregunta); 
} 


ostream& operator<<(ostream &os, const ResultadoRI &res){ 
  os << res.vSimilitud << "\t\t" << res.idDoc << "\t" << res.numPregunta << endl; 
  return os; 
}
 
////////////////////////////////////////////////////////////////////////7

Buscador::Buscador(const string& directorioIndexacion, const int& f) 
    : IndexadorHash(directorioIndexacion), 
      formSimilitud(f), 
      c(2.0), 
      k1(1.2), 
      b(0.75)
    {
        if (formSimilitud != 0 && formSimilitud != 1) {
            cerr << "Valor de formSimilitud no válido. Se ha inicializado a 0 (DFR) por defecto." << endl;
            formSimilitud = 0; 
        }
}

Buscador::Buscador(const Buscador& other) 
    : IndexadorHash(other), 
      formSimilitud(other.formSimilitud),
      c(other.c), 
      k1(other.k1), 
      b(other.b) 
    {
        this->docsOrdenados = other.docsOrdenados;
}

Buscador::~Buscador() {
    
}

Buscador& Buscador::operator= (const Buscador& other) {
    if (this != &other) {
        IndexadorHash::operator=(other);
        formSimilitud = other.formSimilitud;
        c = other.c;
        k1 = other.k1;
        b = other.b;
        docsOrdenados = other.docsOrdenados;
    }
    return *this;
}

/*bool Buscador::Buscar(const int& numDocumentos) {
    string preg;
    if (!DevuelvePregunta(preg) || preg.empty()) {
        cerr << "No hay ninguna pregunta indexada para realizar la búsqueda." << endl;
        return false;
    }

    InformacionPregunta infP;
    DevuelvePregunta(infP);
    if (!buscarDOCS){
        this->docsOrdenados = priority_queue<ResultadoRI>();
    }
    unordered_map<long int, double> relevanciaDocs;
    double N = (double)getNumDocsIndexados();
    double avg_ld = getAvg_ld();
    int k = getPalSinParadaPreg();
    
    InformacionTerminoPregunta infPreg;
    InformacionTermino infTerm;
    
    string term;
    term.reserve(256);
    istringstream termss(preg);
    try{
        unordered_set<string> termsProcesados;

        while(termss >> term){

            if (termsProcesados.count(term)){
                continue;
            }
            
            termsProcesados.insert(term);

            if (DevuelvePregunta(term, infPreg)) {
                int ftP = infPreg.getFt(); // Frecuencia total del término en la pregunta
                
                if (Devuelve(term, infTerm)) {
                    
                    int ftc = infTerm.getFtc(); // Frecuencia total del término en la colección
                    double lambda_t = (double)ftc / N; // Probabilidad de aparición del término en la colección
                    int n = infTerm.getLDocs_const().size(); // Número de documentos que contienen el término

                    for(const auto& [nomDoc, infDoc] : infTerm.getLDocs()) {

                        int ft = infDoc.getFt(); // Frecuencia del término en el documento 
                        int ld = getLongitudDoc(nomDoc); // Longitud del documento 
                        
                        double relevancia = 0.0;

                        if (formSimilitud == 0) { // DFR
                            double w_tq = (double)ftP / k;
                            double f_star = ft * log2(1.0 + (c * avg_ld) / (double)ld);

                            double parte_log = log2(1.0 + lambda_t) + f_star * log2((1.0 + lambda_t) / lambda_t);
                            double parte_norm = (double)(ftc + 1) / ((double)n * (f_star + 1.0));
                            double w_td = parte_log * parte_norm;

                            relevancia = w_tq * w_td;
                            string nomDocStr;
                            DevuelveNombreDocumento(nomDoc, nomDocStr);
                            //cout<< "nombre: " << nomDocStr << "ftp: " << ftP << "\tftc: " << ftc << "\tN: " << N << "\tavg_ld: " << avg_ld << "\tld: " << ld << "\tf_star: " << f_star << "\tw_tq: " << w_tq << "\tw_td: " << w_td << "\trelevancia: " << relevancia << "\tk: " << k << "\tn: " << n << "ft: " << ft << endl;
                        } 
                        else if (formSimilitud == 1) { // BM25
                            double idf = log2((N - n + 0.5) / (n + 0.5));
                            double tf_norm = (ft * (k1 + 1.0)) / (ft + k1 * (1.0 - b + b * ((double)ld / avg_ld)));

                            relevancia = idf * tf_norm;
                            //cout<< "nombre: " << nomDoc << "\tftp: " << ftP << "\tftc: " << ftc << "\tN: " << N << "\tavg_ld: " << avg_ld << "\tld: " << ld << "\tidf: " << idf << "\tf_tq: " << ftP / k << "\tf_t_d_norm: " << tf_norm << "\tidf:" << idf << "\trelevancia: " << relevancia << endl;
                        }

                        relevanciaDocs[nomDoc] += relevancia;
                    }
                } 
            }
        }

        vector<ResultadoRI> v;
        v.reserve(relevanciaDocs.size());

        for (auto const& [id, score] : relevanciaDocs) {
            v.push_back(ResultadoRI(score, id, preguntaID));
        }

        sort(v.begin(), v.end(), [](const ResultadoRI& a, const ResultadoRI& b) {
            return a.VSimilitud() > b.VSimilitud(); // Ordenar de mayor a menor relevancia
        });

        for (size_t i = 0; i < v.size() && i < (size_t)numDocumentos; ++i) {
            docsOrdenados.push(v[i]);
        }

        //return !docsOrdenados.empty();
        return true;

    } catch (const bad_alloc& e) {
        cerr << "ERROR: Falta de memoria durante la búsqueda." << endl;
        return false;
    } catch (...) {
        cerr << "ERROR: Error inesperado durante la búsqueda." << endl;
        return false;
    }
}*/

bool Buscador::Buscar(const int& numDocumentos) {
    string preg;
    if (!DevuelvePregunta(preg) || preg.empty()) {
        cerr << "No hay ninguna pregunta indexada para realizar la búsqueda." << endl;
        return false;
    }

    if (!buscarDOCS) {
        //this->docsOrdenados = priority_queue<ResultadoRI>();
        docsOrdenados.clear();
    }

    unordered_map<long int, double> relevanciaDocs;
    relevanciaDocs.reserve(getNumDocsIndexados()); // evita rehashing

    const double N      = (double)getNumDocsIndexados();
    const double avg_ld = getAvg_ld();
    const int    k      = getPalSinParadaPreg(); // constante para toda la búsqueda

    InformacionTerminoPregunta infPreg;
    InformacionTermino infTerm;

    unordered_map<string, InformacionTerminoPregunta>& indicePreg = const_cast<unordered_map<string, InformacionTerminoPregunta>&>(getIndicePregunta());

    try {
        // Itera sobre términos únicos directamente, sin istringstream ni set
        for (const auto& [term, infPreg] : indicePreg) {

            if (!Devuelve(term, infTerm)) continue;

            const int    ftP      = infPreg.getFt();
            const int    ftc      = infTerm.getFtc();
            const double lambda_t = (double)ftc / N;
            const int    n        = (int)infTerm.getLDocs_const().size();

            for (const auto& [nomDoc, infDoc] : infTerm.getLDocs()) {
                const int    ft = infDoc.getFt();
                const int    ld = getLongitudDoc(nomDoc);
                double relevancia = 0.0;

                if (formSimilitud == 0) { // DFR
                    const double w_tq      = (double)ftP / k;
                    const double f_star    = ft * log2(1.0 + (c * avg_ld) / (double)ld);
                    const double parte_log = log2(1.0 + lambda_t) + f_star * log2((1.0 + lambda_t) / lambda_t);
                    const double parte_norm= (double)(ftc + 1) / ((double)n * (f_star + 1.0));
                    relevancia = w_tq * parte_log * parte_norm;
                }
                else if (formSimilitud == 1) { // BM25
                    const double idf     = log2((N - n + 0.5) / (n + 0.5));
                    const double tf_norm = (ft * (k1 + 1.0)) / (ft + k1 * (1.0 - b + b * ((double)ld / avg_ld)));
                    relevancia = idf * tf_norm;
                }

                relevanciaDocs[nomDoc] += relevancia;
            }
        }

        vector<ResultadoRI> v;
        v.reserve(relevanciaDocs.size());

        for (const auto& [id, score] : relevanciaDocs) {
            v.emplace_back(score, id, preguntaID); // emplace_back evita copia
        }

        // partial_sort si solo necesitas los top-N, más eficiente que sort completo
        /*int topN = min((int)v.size(), numDocumentos);
        partial_sort(v.begin(), v.begin() + topN, v.end(),
            [](const ResultadoRI& a, const ResultadoRI& b) {
                return a.VSimilitud() > b.VSimilitud();
            });

        for (int i = 0; i < topN; ++i) {
            docsOrdenados.push(v[i]);
        }
        */

        // operator< ordena: misma pregunta → menor similitud primero
        // distinta pregunta → mayor numPregunta primero
        sort(v.begin(), v.end());

        // Los de mayor similitud están al final, volcamos los últimos topN
        /*int topN = min((int)v.size(), numDocumentos);
        for (int i = (int)v.size() - 1; i >= (int)v.size() - topN; --i) {
            docsOrdenados.emplace_back(v[i]);
        }
        */
        int topN = min((int)v.size(), numDocumentos);
        for (int i = (int)v.size() - topN; i < (int)v.size(); ++i) {
            docsOrdenados.emplace_back(v[i]); // menor a mayor
        }

        return true;

    } catch (const bad_alloc& e) {
        cerr << "ERROR: Falta de memoria durante la búsqueda." << endl;
        return false;
    } catch (...) {
        cerr << "ERROR: Error inesperado durante la búsqueda." << endl;
        return false;
    }
}

bool Buscador::Buscar(const string& dirPreguntas, const int& numDocumentos, const int& numPregInicio, const int& numPregFin) {
    //docsOrdenados = priority_queue<ResultadoRI>();
    docsOrdenados.clear();
    buscarDOCS = true;

    for (int i = numPregInicio; i <= numPregFin; ++i) {
        string rutaPregunta = dirPreguntas + to_string(i) + ".txt";
        ifstream f(rutaPregunta);
        if (!f.is_open()) {
            cerr << "ERROR: No se pudo abrir el fichero de la pregunta: " << rutaPregunta << endl;
            continue;
        }

        string pregunta;
        getline(f, pregunta);
        f.close();

        if (pregunta.empty()) {
            cerr << "ERROR: La pregunta está vacía en el fichero: " << rutaPregunta << endl;
            continue;
        }

        if (!IndexarPregunta(pregunta)) {
            cerr << "ERROR: No se pudo indexar la pregunta del fichero: " << rutaPregunta << endl;
            continue;
        }
        preguntaID = i;
        if (!Buscar(numDocumentos)) {
            cerr << "ERROR: No se pudo realizar la búsqueda para la pregunta del fichero: " << rutaPregunta << endl;
            continue;
        }
    }
    buscarDOCS = false;
    return !docsOrdenados.empty();
}

void Buscador::ImprimirResultadoBusqueda(const int& numDocumentos) const {
    // Como el método es const, no podemos modificar "docsOrdenados" directamente.
    // Hacemos una copia para ir vaciándola con .pop() sin perder los datos originales.
    //priority_queue<ResultadoRI> copiaCola = docsOrdenados;
    vector<ResultadoRI> copiaCola = docsOrdenados; // Asumiendo que docsOrdenados es un vector, no una priority_queue

    string formula = (formSimilitud == 0) ? "DFR" : "BM25";
    
    int preguntaActual = -1;
    int posicionPregunta = 0;

    string nombreDoc;
    nombreDoc.reserve(256);

    while (!copiaCola.empty()) {
        //ResultadoRI& res = copiaCola.top();
        const ResultadoRI& res = copiaCola.back();
        int numPregunta = res.NumPregunta();
        //copiaCola.pop();
        copiaCola.pop_back();

        // Control del cambio de pregunta para reiniciar el contador de posición
        if (numPregunta != preguntaActual) {
            preguntaActual = numPregunta;
            posicionPregunta = 0;
        }

        // Si ya hemos impreso el máximo de documentos solicitados para ESTA pregunta,
        // saltamos este elemento y pasamos al siguiente.
        if (posicionPregunta >= numDocumentos) {
            continue;
        }

        DevuelveNombreDocumento(res.IdDoc(), nombreDoc);

        size_t ultimaBarra = nombreDoc.find_last_of("/\\");
        size_t ultimoPunto = nombreDoc.find_last_of(".");

        if (ultimoPunto != string::npos && ultimoPunto > ultimaBarra) {
            nombreDoc = nombreDoc.substr(ultimaBarra + 1, ultimoPunto - ultimaBarra - 1);
        }
        // ---------------------------------------------

        // Determinar la cadena de la pregunta indexada
        string textoPregunta = (numPregunta == 0) ? "PreguntaIndexada" : "ConjuntoDePreguntas";
        // Nota: Si para numPregunta == 0 necesitas el texto real de la pregunta,
        // puedes usar: if (numPregunta == 0) DevuelvePregunta(textoPregunta);
        string pregunta;
        DevuelvePregunta(pregunta);
        // Imprimir la línea con el formato exacto requerido por trec_eval
        cout << numPregunta << " "
             << formula << " "
             << nombreDoc << " "
             << posicionPregunta << " "
             << fixed << setprecision(6) << res.VSimilitud() << " "
             << pregunta << "\n";

        posicionPregunta++;
    }
}

/*bool Buscador::ImprimirResultadoBusqueda(const int& numDocumentos, const string& nombreFichero) const {
    if (nombreFichero.empty()) {
        cerr << "Nombre de fichero no válido." << endl;
        return false;
    }

    ofstream outFile(nombreFichero);

    if (outFile.is_open()) {
        //priority_queue<ResultadoRI> copiaResultados = docsOrdenados;
        vector<ResultadoRI> copiaResultados = docsOrdenados;

        for (int i = 0; i < numDocumentos && !copiaResultados.empty(); ++i) {
            //const ResultadoRI& res = copiaResultados.top();
            const ResultadoRI& res = copiaResultados.back();
            outFile << res << endl;
            //copiaResultados.pop();
            copiaResultados.pop_back();
        }
        outFile.close();
        return true;
    } 
    else {
        cerr << "ERROR: No se pudo crear el fichero de salida: " << nombreFichero << endl;
        return false;   
    }
}*/

bool Buscador::ImprimirResultadoBusqueda(const int& numDocumentos, const string& nombreFichero) const {
    if (nombreFichero.empty()) {
        cerr << "Nombre de fichero no válido." << endl;
        return false;
    }

    ofstream outFile(nombreFichero);
    if (!outFile.is_open()) {
        cerr << "ERROR: No se pudo crear el fichero: " << nombreFichero << endl;
        return false;
    }

    vector<ResultadoRI> copiaResultados = docsOrdenados;
    string formula = (formSimilitud == 0) ? "DFR" : "BM25";

    int preguntaActual = -1;
    int posicionPregunta = 0;
    string nombreDoc;
    nombreDoc.reserve(256);

    // Igual que ImprimirResultadoBusqueda por pantalla pero escribiendo en fichero
    while (!copiaResultados.empty()) {
        const ResultadoRI& res = copiaResultados.back();
        int numPregunta = res.NumPregunta();
        copiaResultados.pop_back();

        if (numPregunta != preguntaActual) {
            preguntaActual = numPregunta;
            posicionPregunta = 0;
        }

        if (posicionPregunta >= numDocumentos) continue;

        DevuelveNombreDocumento(res.IdDoc(), nombreDoc);

        // Quitar ruta y extensión
        size_t ultimaBarra = nombreDoc.find_last_of("/\\");
        size_t ultimoPunto = nombreDoc.find_last_of(".");
        if (ultimoPunto != string::npos && ultimoPunto > ultimaBarra) {
            nombreDoc = nombreDoc.substr(ultimaBarra + 1, ultimoPunto - ultimaBarra - 1);
        }

        string pregunta;
        DevuelvePregunta(pregunta);

        outFile << numPregunta << " "
                << formula << " "
                << nombreDoc << " "
                << posicionPregunta << " "
                << fixed << setprecision(6) << res.VSimilitud() << " "
                << "ConjuntoDePreguntas" << "\n";

        posicionPregunta++;
    }

    outFile.close();
    return true;
}

int Buscador::DevolverFormulaSimilitud() const {
    return formSimilitud;
}

bool Buscador::CambiarFormulaSimilitud(const int& f) {
    if (f == 0 || f == 1) {
        formSimilitud = f;
        return true;
    } else {
        //cerr << "Valor de formSimilitud no válido. No se ha cambiado el valor." << endl; ////////////////////////////// MENSAJE DE ERROR EN EL CORRIGEALUMNO.SH
        return false;
    }
}

void Buscador::CambiarParametrosDFR(const double& kc) {
    this->c = kc;
}

double Buscador::DevolverParametrosDFR() const {
    return c;
}

void Buscador::CambiarParametrosBM25(const double& kk1, const double& kb) {
    this->k1 = kk1;
    this->b = kb;
}

void Buscador::DevolverParametrosBM25(double& kk1, double& kb) const {
    // Return BM25 parameters implementation
    kk1 = this->k1;
    kb = this->b;
}