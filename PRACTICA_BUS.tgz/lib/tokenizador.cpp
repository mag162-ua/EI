#include <iostream>
#include <list>
#include <cctype>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <locale>
#include <algorithm>
#include <fstream>
#include <sys/stat.h>
#include "../include/tokenizador.h"
#include <filesystem>

using namespace std;

unsigned char Tokenizador::mapa_minusculas[256];

void Tokenizador::inicializar_delimitadores_especiales(){

    DELIMITADOR_URL[(unsigned char)':'] = true;
    DELIMITADOR_URL[(unsigned char)'/'] = true;
    DELIMITADOR_URL[(unsigned char)'.'] = true;
    DELIMITADOR_URL[(unsigned char)'?'] = true;
    DELIMITADOR_URL[(unsigned char)'&'] = true;
    DELIMITADOR_URL[(unsigned char)'='] = true;
    DELIMITADOR_URL[(unsigned char)'-'] = true;
    DELIMITADOR_URL[(unsigned char)'#'] = true;
    DELIMITADOR_URL[(unsigned char)'@'] = true;
    DELIMITADOR_URL[(unsigned char)'_'] = true;

    DELIMITADOR_DECIMAL[(unsigned char)'.'] = true;
    DELIMITADOR_DECIMAL[(unsigned char)','] = true;

    //Conversi�n MinusculasSinAcentos
    for (int i = 0; i < 256; ++i) mapa_minusculas[i] = (unsigned char)i;

    // A-Z est�ndar (ASCII)
    for (int i = 0x41; i <= 0x5A; ++i) mapa_minusculas[i] = i + 32;

    // Variantes de 'a' (� � � � � � � � � � � �) -> 'a'
    for (unsigned char c : {0xC0, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xE0, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5}) 
        mapa_minusculas[c] = 'a';

    // Variantes de 'e' (� � � � � � � �) -> 'e'
    for (unsigned char c : {0xC8, 0xC9, 0xCA, 0xCB, 0xE8, 0xE9, 0xEA, 0xEB}) 
        mapa_minusculas[c] = 'e';

    // Variantes de 'i' (� � � � � � � �) -> 'i'
    for (unsigned char c : {0xCC, 0xCD, 0xCE, 0xCF, 0xEC, 0xED, 0xEE, 0xEF}) 
        mapa_minusculas[c] = 'i';

    // Variantes de 'o' (� � � � � � � � � � � �) -> 'o'
    for (unsigned char c : {0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD8, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF8}) 
        mapa_minusculas[c] = 'o';

    // Variantes de 'u' (� � � � � � � �) -> 'u'
    for (unsigned char c : {0xD9, 0xDA, 0xDB, 0xDC, 0xF9, 0xFA, 0xFB, 0xFC}) 
        mapa_minusculas[c] = 'u';

    // Caso de la '�': � (0xD1) pasa a � (0xF1), pero la � se queda como �
    mapa_minusculas[0xD1] = 0xF1; 

    // Otros casos: �/� -> c, �/�/� -> y
    mapa_minusculas[0xC7] = mapa_minusculas[0xE7] = 'c';
    mapa_minusculas[0xDD] = mapa_minusculas[0xFD] = mapa_minusculas[0xFF] = 'y';
}

ostream& operator<<(ostream& os, const Tokenizador& t){
    os << "DELIMITADORES: " << t.DelimitadoresPalabra() << " TRATA CASOS ESPECIALES: " << t.CasosEspeciales() << " PASAR A MINUSCULAS Y SIN ACENTOS: " << t.PasarAminuscSinAcentos();
    return os;
}

Tokenizador::Tokenizador (const string& delimitadoresPalabra, const bool& kcasosEspeciales, const bool& minuscSinAcentos){	
    inicializar_delimitadores_especiales();
    this->delimiters = "";
    this->CasosEspeciales(kcasosEspeciales);
    this->DelimitadoresPalabra(delimitadoresPalabra);
    this->PasarAminuscSinAcentos(minuscSinAcentos);
}

Tokenizador::Tokenizador (const Tokenizador& token){
    inicializar_delimitadores_especiales();
    this->delimiters = "";
    this->CasosEspeciales(token.CasosEspeciales());
    this->DelimitadoresPalabra(token.DelimitadoresPalabra());
    this->pasarAminuscSinAcentos = token.pasarAminuscSinAcentos;
}

Tokenizador::Tokenizador (){	
    inicializar_delimitadores_especiales();
    this->delimiters = "";
    this->CasosEspeciales(true);
    this->DelimitadoresPalabra(",;:.-/+*\\ '\"{}[]()<>?!??&#=\t@");
    this->pasarAminuscSinAcentos = false;
}

Tokenizador::~Tokenizador (){
    this->delimiters = "";
    this->CasosEspeciales(false);
    this->DelimitadoresPalabra("");
    this->pasarAminuscSinAcentos = false;
}

Tokenizador& Tokenizador::operator= (const Tokenizador& token){
    this->delimiters = token.delimiters;
    this->casosEspeciales = token.casosEspeciales;
    this->pasarAminuscSinAcentos = token.pasarAminuscSinAcentos;
    return *this;
}

void Tokenizador::minuscSinAcentos(string& str) const{ 
    size_t len = str.length();

    for (size_t i = 0; i < len; ++i) {
        // Accedemos a la tabla usando el car�cter actual como �ndice y guardamos el resultado (que ya es la min�scula sin acento)
        str[i] = mapa_minusculas[(unsigned char)str[i]];
    }

}

size_t Tokenizador::tratar_url(const string& str,const int& inicio) const{

    size_t prefix_len = 0;
    size_t str_len = str.length();
    
    // Comparamos desde 'inicio' los caracteres necesarios.
    if (str.compare(inicio, 6, "https:") == 0) prefix_len = 6;
    else if (str.compare(inicio, 5, "http:") == 0) prefix_len = 5;
    else if (str.compare(inicio, 4, "ftp:") == 0) prefix_len = 4;

    if (prefix_len == 0 || (size_t)inicio + prefix_len > str.size()) {
        return string::npos;
    }

    size_t i = inicio + prefix_len;

    for (; i < str_len; ++i) {

        // Si es un delimitador de URL (.:/?&=#@...), seguimos adelante
        if (this->DELIMITADOR_URL[(unsigned char)str[i]]) {
            continue;
        }

        // Si es un delimitador general del tokenizador, la URL termina
        if (this->delimitadores[(unsigned char)str[i]]) {
            if(i == prefix_len){ // Si el ultimo caracter es : de http: se elimina
                i--;
            }
            break;
        }
    }

    return i;
}

size_t Tokenizador::tratar_decimal(const string& str,const int& inicio,const size_t& primer_sig) const{
    
    size_t i = inicio;
    size_t str_len = str.length();

    //Comprobamos antes del primer .,
    for(;i < primer_sig;i++){
        if (!isdigit((unsigned char) str[i])){ //si algun caractr no es un n�mero
            return string::npos;
        }
    }

    i = primer_sig+1;

    if (i >= str_len || !isdigit((unsigned char)str[i])){ // Si el primer signo se encuentra en el final del string o el siguiente carac ter no es un n�mero
        return string::npos;
    }

    size_t pos_signo = primer_sig;

    for(; i < str_len; i++){

        if (isdigit((unsigned char)str[i])){ // Si es un n�mero seguimos
            continue;
        }
        else{
            if (this->DELIMITADOR_DECIMAL[(unsigned char)str[i]]) {
                if (i == pos_signo + 1){ // Dos signos juntos
                    return string::npos;
                }
                pos_signo = i;
                continue;
            }

            if ((unsigned char)str[i] == '%' || (unsigned char)str[i] == '$'){
                if (i == pos_signo + 1){ // si %$ se encuentra justo despues de ,. no es un n�mero
                    return string::npos;
                }
                //Comprueba al final del string, caracter seguido es un caracter blanco
                if (i == str_len - 1 || ((unsigned char)str[i+1] == ' ' || (unsigned char)str[i+1] == '\t' || (unsigned char)str[i+1] == '\n' || (unsigned char)str[i+1] == '\r')){ // Si el s?mbolo de porcentaje o d?lar no est? al final del token, no es un n?mero v?lido
                    i = i+1;
                    break;
                }
                else{
                    return string::npos;
                }
            }

            if(this->delimitadores[(unsigned char)str[i]]){
                if (i == pos_signo + 1){ // Si '.,' seguido de Delimitador, se elimina el .
                    i--;
                    break;
                }
                break;
            }

            return string::npos;
        }

    }
    
    return i;
}

size_t Tokenizador::tratar_email(const string& str,const int& inicio,const size_t& primer_arroba) const{
    if (primer_arroba == (size_t)inicio){ // @ no es el primer caracter
        return string::npos;
    }

    size_t str_len = str.length();

    if (primer_arroba + 1 >= str_len || this->delimitadores[(unsigned char)str[primer_arroba + 1]]) { // @ esta al final de str o est� seguido de un delimitador
        return string::npos;
    }

    size_t i = primer_arroba + 1;
    size_t ult_sig = primer_arroba;

    for(;i < str_len; i++){

        if ((unsigned char)str[i] == '.' || (unsigned char)str[i] == '-' || (unsigned char)str[i] == '_'){ // si caracter .-_
            if (i == ult_sig + 1){ // Dos signos seguido
                i--;
                break;
            }
            ult_sig = i;
            continue;
        }

        if ((unsigned char)str[i] == '@'){ // Se encuentra un segundo @
            return string::npos;
        }

        if(this->delimitadores[(unsigned char)str[i]]){ // Encontramos delimitador
            if (i == ult_sig + 1){ // Si el caracter anterior fue un signo, se elimina
                i--;
                break;
            }
            break;
        }
    }

    return i;
}

size_t Tokenizador::tratar_acronimo(const string& str,const int& inicio,const size_t& primer_punto) const{

    if (primer_punto == (size_t)inicio){ //punto en la primera posici�n
        return string::npos;
    }

    size_t i = primer_punto + 1;
    size_t str_len = str.length();
    size_t ultimo_punto = primer_punto;

    for(;i < str_len; i++){

        if((unsigned char)str[i] == '.'){ // Encuentra .
            if(i == ultimo_punto + 1){ //Dos puntos seguidos, se elimina los dos puntos seguidos
                i--;
                break;
            }
            ultimo_punto = i;
            continue;
        }

        if(this->delimitadores[(unsigned char)str[i]]){ // Encontramos delimitador
            if(i == ultimo_punto + 1){ // terminado en punto, se elimina el punto sobrante
                i--;
                break;
            }
            break;
        }
    }

    return i;
}

size_t Tokenizador::tratar_multipalabra(const string& str,const int& inicio,const size_t& primer_guion) const{
    if(inicio == (size_t)primer_guion){ //Guion en la primera posici�n
        return string::npos;
    }

    size_t i = primer_guion + 1;
    size_t str_len = str.length();
    size_t ultimo_guion = primer_guion;

    for(; i < str_len; i++){
        
        if ((unsigned char)str[i] == '-'){ // Caracter -
            if (i == ultimo_guion + 1){ // Si dos giones juntos
                i--;
                break;
            }
            ultimo_guion = i;
            continue;
        }
        if(this->delimitadores[(unsigned char)str[i]]){ //Encontramos delimitador
            if (i == ultimo_guion + 1){ //Terminado en guion se elimina el guion
                i--;
                break;
            }
            break;
        }
    }

    return i;
}

void Tokenizador::Tokenizar (const string& str, list<string>& tokens) const{

    tokens.clear();
    if (str.empty()){ //Si str est� vacio
        return;
    }

    string str_analisis;
    str_analisis.reserve(str.size() + 1); // Pre-reservamos memoria para evitar copias
    str_analisis = str;
    if(this->pasarAminuscSinAcentos){
        this->minuscSinAcentos(str_analisis);
    } 
    str_analisis.push_back('\n'); // A�adimos el salto de l�nea al final (instant�neo)

    size_t inicio = 0;
    size_t longitud = str_analisis.size();
    bool caracter_plus = false;

    const char* data = str_analisis.data();

    for(size_t i = 0; i < longitud; ++i){
        size_t token = string::npos;

        if (this->delimitadores[(unsigned char)data[i]]){

            if (this->CasosEspeciales()){

                if (this->DELIMITADOR_URL[(unsigned char)data[i]]){
                    token = tratar_url(str_analisis, inicio);
                }

                if (token == string::npos && this->DELIMITADOR_DECIMAL[(unsigned char)data[i]]){
                    token = tratar_decimal(str_analisis, inicio, i);
                    if (token != string::npos && this->DELIMITADOR_DECIMAL[(unsigned char)data[inicio]]){
                        caracter_plus = true;
                    }
                }

                if (token == string::npos && (unsigned char)data[i] == '@'){
                    token = tratar_email(str_analisis, inicio, i);
                }

                if (token == string::npos && (unsigned char)data[i] == '.'){
                    token = tratar_acronimo(str_analisis, inicio, i);
                }

                if (token == string::npos && (unsigned char)data[i] == '-'){
                    token = tratar_multipalabra(str_analisis, inicio, i);
                }

                if (token == string::npos){ // si token no es un caso especial
                    if (i > inicio) { // Si hay contenido
                        tokens.emplace_back(str_analisis.data() + inicio, i - inicio);
                    }
                    inicio = i + 1;
                    continue;
                }
                else{
                    if (caracter_plus){ // A�adido de 0 en decimal
                        string carater_plus_c = "0";
                        tokens.emplace_back(carater_plus_c.append(str_analisis.data() + inicio, token - inicio));
                        caracter_plus = false;
                    }
                    else{
                        tokens.emplace_back(str_analisis.data() + inicio, token - inicio);
                    }
                    i = token;
                    inicio = i + 1;
                    continue;
                }
            }
            else{ // No es caso especial
                if (inicio == i){
                    inicio += 1;
                    continue;
                }
                tokens.emplace_back(str_analisis.data() + inicio, i - inicio);
                inicio = i + 1;
                continue;
            }
        }
    }
}

bool Tokenizador::Tokenizar (const string& i, const string& f) const{
    // Apertura del archivos del que leer
    ifstream entrada(i);
    if (!entrada) { // Si no se pudo abrir
        cerr << "ERROR: No existe el archivo: " << i << '\n';
        return false;
    }

    //Apertura del archivo del que escribir
    ofstream salida(f); 
    if (!salida) { // Si no se pudo abrir
        cerr << "ERROR: No se pudo crear/escribir el archivo de salida: " << f << '\n';
        return false;
    }

    string cadena;
    cadena.reserve(1024);
    list<string> tokens;

    // Bucle de lectura
    while (getline(entrada, cadena)) { //Se obtiene la linea 
        if (!cadena.empty()) {
            Tokenizar(cadena, tokens); // Tokenizamos la l?nea actual
            
            for (const string& token : tokens) {// Escribimos los tokens en el fichero de salida
                salida << token << '\n';
            }
        }
    }

    return true;
}
/**
bool Tokenizador::Tokenizar(const string& i, const string& f) const {

    // Abrir y leer el archivo ENTERO de una sola vez ────────────────
    ifstream entrada(i, ios::binary | ios::ate);
    if (!entrada) {
        cerr << "ERROR: No existe el archivo: " << i << '\n';
        return false;
    }

    const streamsize tam = entrada.tellg();
    entrada.seekg(0, ios::beg);

    string buffer;
    buffer.resize(static_cast<size_t>(tam));
    if (tam > 0 && !entrada.read(buffer.data(), tam)) {
        cerr << "ERROR: Fallo al leer el archivo: " << i << '\n';
        return false;
    }
    entrada.close();

    // Abrir salida con buffer del mismo tamaño que la entrada ──────
    ofstream salida(f, ios::binary);
    if (!salida) {
        cerr << "ERROR: No se pudo crear/escribir el archivo de salida: " << f << '\n';
        return false;
    }

    salida.rdbuf()->pubsetbuf(buffer.data(), static_cast<streamsize>(tam));

    list<string> tokens;
    string cadena;

    const char* data = buffer.data();
    const size_t total = static_cast<size_t>(tam);
    size_t pos = 0;

    // Partición del buffer sin getline() ────────────────────────────
    while (pos <= total) {
        size_t fin = pos;
        while (fin < total && data[fin] != '\n' && data[fin] != '\r')
            ++fin;

        cadena.assign(data + pos, fin - pos); // reutiliza capacidad

        if (!cadena.empty()) {
            Tokenizar(cadena, tokens); // ← llamada requerida, sin cambios

            for (const string& token : tokens)
                salida << token << '\n';
        }

        // Avanzar pasando '\n' (y '\r' si hay CRLF)
        pos = fin + 1;
        if (pos < total && data[pos - 1] == '\r' && data[pos] == '\n')
            ++pos;

        if (fin == total) break; // fin del archivo sin '\n' final
    }

    return true;
    // destructor de salida vuelca el buffer de escritura restante
}
*/
bool Tokenizador::Tokenizar (const string & i) const{
    return this->Tokenizar(i,i+".tk");
}

bool Tokenizador::TokenizarListaFicheros (const string& i) const{
    // Apertura del archivos del que leer
    ifstream lista_ficheros(i);
    if (!lista_ficheros.is_open()) { // Si no se pudo abrir
        cerr << "ERROR: No existe o no se pudo abrir el archivo de lista: " << i << '\n';
        return false;
    }

    string archivo_actual;
    bool todoCorrecto = true; // Se volver� false si falla la apertura de la lista o alg?n archivo
    struct stat info_archivo; // Estructura para almacenar informaci?n de la ruta

    // Leemos el archivo l?nea a l?nea
    while (getline(lista_ficheros, archivo_actual)) {
        
        if (archivo_actual.empty()) { // Saltamos l�neas vac�as
            continue;
        }

        if (stat(archivo_actual.c_str(), &info_archivo) != 0) { // stat() devuelve 0 si tiene �xito obteniendo la info del archivo
            cerr << "ERROR: El archivo listado no existe o no es accesible: " << archivo_actual << '\n';
            todoCorrecto = false;
            continue; // seguimos
        }

        if (S_ISDIR(info_archivo.st_mode)) {// Comprobamos si la ruta pertenece a un directorio
            cerr << "ERROR: La ruta es un directorio, no un archivo: " << archivo_actual << '\n';
            todoCorrecto = false;
            continue; // Pasamos al siguiente
        }

        // Generamos el nombre del archivo de salida a�adiendo ".tk"
        string archivo_salida = archivo_actual + ".tk";

        // Si este devuelve false, marcamos todoCorrecto a false, pero seguimos procesando.
        if (!Tokenizar(archivo_actual, archivo_salida)) {
            todoCorrecto = false;
        }
    }

    // El destructor de ifstream cierra la lista autom?ticamente
    return todoCorrecto;
}

bool Tokenizador::TokenizarDirectorio (const string& i) const{
    
    if (!std::filesystem::exists(i) || !std::filesystem::is_directory(i)) { // Comprobamos si el directorio existe y es v�lido
        cerr << "ERROR: No existe el directorio: " << i << endl;
        return false;
    }

    
    for (const auto& entrada : std::filesystem::recursive_directory_iterator(i)) { //Navegaci�n subdirectorio
        
        if (std::filesystem::is_regular_file(entrada)) { // Comprobaci�n que se a un fichero
            
            string ruta_archivo = entrada.path().string(); // Sacamos la ruta completa del archivo
            
            this->Tokenizar(ruta_archivo);
        }
    }
    
    return true;
}

void Tokenizador::DelimitadoresPalabra(const string& nuevoDelimiters){
    std::fill(std::begin(this->delimitadores), std::end(this->delimitadores), false); //Todos los valores del array a false

    this->delimiters = "";
    this->delimiters.reserve(nuevoDelimiters.size()); // Pre-reservamos el string de salida

    this->delimitadores[(unsigned char)'\n'] = true;
    this->delimitadores[(unsigned char)'\r'] = true;

    if (this->casosEspeciales) {
        this->delimitadores[(unsigned char)' '] = true;
    }

    for (unsigned char letra : nuevoDelimiters) {
        // Hacemos cast a unsigned char para evitar �ndices negativos con caracteres raros/acentos
        if (!this->delimitadores[(unsigned char)letra]){
            this->delimitadores[(unsigned char)letra] = true;
            this->delimiters += letra;
        }
        else if (letra == ' ' && this->delimiters.find(' ') == string::npos){
            this->delimiters += letra;
        }
    }
}

void Tokenizador::AnyadirDelimitadoresPalabra(const string& nuevoDelimiters){ 
    DelimitadoresPalabra(this->delimiters + nuevoDelimiters);
}

string Tokenizador::DelimitadoresPalabra() const{
    return this->delimiters;
}

void Tokenizador::CasosEspeciales (const bool& nuevoCasosEspeciales){
    
    this->casosEspeciales = nuevoCasosEspeciales;

    if (nuevoCasosEspeciales) {
        // Si activamos casos especiales, el espacio SIEMPRE es delimitador
        this->delimitadores[(unsigned char)' '] = true;
    } 
    else {
        // Si desactivamos, el espacio solo es delimitador si est� en la cadena 'delimiters'
        if (this->delimiters.find(' ') == string::npos) {
            this->delimitadores[(unsigned char)' '] = false;
        }
    }
}

bool Tokenizador::CasosEspeciales () const{
    return this->casosEspeciales;
}

void Tokenizador::PasarAminuscSinAcentos (const bool& nuevoPasarAminuscSinAcentos){
    this->pasarAminuscSinAcentos = nuevoPasarAminuscSinAcentos;
}

bool Tokenizador::PasarAminuscSinAcentos () const{
    return this->pasarAminuscSinAcentos;
}