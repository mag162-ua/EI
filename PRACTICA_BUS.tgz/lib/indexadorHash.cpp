#include <iostream>
#include <vector>
#include <cctype>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <algorithm>
#include <fstream>
#include <filesystem>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include "../include/indexadorHash.h"

using namespace std;

IndexadorHash::IndexadorHash(const string& fichStopWords, const string& delimitadores, const bool& detectComp, const bool& minuscSinAcentos, const string& dirIndice, const int& tStemmer, const bool& almPosTerm)
    // Inicialización directa
    : tok(delimitadores, detectComp, minuscSinAcentos),
      tipoStemmer(tStemmer),
      almacenarPosTerm(almPosTerm),
      directorioIndice(dirIndice),
      ficheroStopWords(fichStopWords)
{
    // Lectura de stop words
    ifstream f(fichStopWords);
    if (!f.is_open()) {
        cerr << "ERROR: No se pudo abrir el fichero de stop words: " << fichStopWords << endl;
        return;
    }

    stopWords.reserve(1024); // Reserva de memoria para el conjunto de stop words

    string linea;
    linea.reserve(256); // Reserva de memoria
    while (getline(f, linea)) {
        if (linea.empty()){
            continue;
        }
        normalizarPalabra(linea);
        stopWords.insert(linea);
    }
    f.close();
}

IndexadorHash::IndexadorHash(const string& directorioIndexacion) {
    // Recuperar indexación desde el directorio dado
    if (!this->RecuperarIndexacion(directorioIndexacion)) {
        cerr << "ERROR: No se pudo recuperar la indexación desde: " << directorioIndexacion << endl;
    }
}

IndexadorHash::IndexadorHash(const IndexadorHash& fh)
    // Inicialización directa de todos los campos a partir de fh
    : indice(fh.indice),
      indiceDocs(fh.indiceDocs),
      informacionColeccionDocs(fh.informacionColeccionDocs),
      pregunta(fh.pregunta),
      indicePregunta(fh.indicePregunta),
      infPregunta(fh.infPregunta),
      stopWords(fh.stopWords),
      ficheroStopWords(fh.ficheroStopWords),
      tok(fh.tok),
      directorioIndice(fh.directorioIndice),
      tipoStemmer(fh.tipoStemmer),
      almacenarPosTerm(fh.almacenarPosTerm)
{}

IndexadorHash::~IndexadorHash() {
    indice.clear();
    indiceDocs.clear();
    stopWords.clear();
    indicePregunta.clear();
}

IndexadorHash& IndexadorHash::operator=(const IndexadorHash& fh) {
    if (this != &fh) {
        indice = fh.indice;
        indiceDocs = fh.indiceDocs;
        informacionColeccionDocs = fh.informacionColeccionDocs;
        stopWords = fh.stopWords;
        tok = fh.tok;
        tipoStemmer = fh.tipoStemmer;
        almacenarPosTerm = fh.almacenarPosTerm;
        directorioIndice = fh.directorioIndice;
        ficheroStopWords = fh.ficheroStopWords;
        pregunta = fh.pregunta;
        indicePregunta = fh.indicePregunta;
        infPregunta = fh.infPregunta;
        stemmer = fh.stemmer;
    }
    return *this;
}

// Normalización de una palabra: minúsculas/acentos + stemmer
bool IndexadorHash::normalizarPalabra(string& word) const {
    if (word.empty()) return false;

    if (tok.PasarAminuscSinAcentos()) { // Si MinusculaSinAcentos es true
        list<string> tokens;
        tok.Tokenizar(word, tokens);
        if (tokens.empty()) {
            return false;
        }
        word = tokens.front();
    }

    if (tipoStemmer != 0 && word.length() > 1) { // Si hay que aplicar stemmer y word tiene más de un carácter
        const_cast<stemmerPorter&>(stemmer).stemmer(word, tipoStemmer);
    }

    return !word.empty();
}

bool IndexadorHash::IndexarDoc(const string& nomDoc) {
    if (!std::filesystem::exists(nomDoc)){ // Si el documento no existe
        return false;
    }

    struct stat info;
    if (stat(nomDoc.c_str(), &info) != 0){
        return false;
    }

    //time_t ctime = info.st_mtime;   // Fecha de modificación
    //long tamBytes = info.st_size;   // Tamaño en bytes directo
    auto ftime = std::filesystem::last_write_time(nomDoc);
    auto sctp = std::chrono::time_point_cast<std::chrono::system_clock::duration>(ftime - std::filesystem::file_time_type::clock::now() + std::chrono::system_clock::now());
    time_t ctime = std::chrono::system_clock::to_time_t(sctp);
    long tamBytes = (long)std::filesystem::file_size(nomDoc);
    
    int idAsignado;
    auto itDoc = indiceDocs.find(nomDoc); 

    if (itDoc != indiceDocs.end()) { // Si el documento ya está indexado
        if (itDoc->second.getFechaModificacion().getTiempo() >= ctime) { // Fecha no es más reciente
            return true; 
        }
        idAsignado = itDoc->second.getIdDoc();
        BorraDoc(nomDoc); // Borramos versión vieja
    } else {
        idAsignado = (int)indiceDocs.size() + 1;
    }

    ifstream f(nomDoc);
    if (!f.is_open()) return false;

    string linea;
    int numTotalPal = 0;
    int numPalSinParada = 0;
    int posActual = 0;
    unordered_set<string> palabrasDiferentesDoc;
    list<string> tokensLinea;
    tokensLinea.resize(512); // Reserva de memoria para tokenización de líneas
    linea.reserve(512); // Reserva de memoria para lectura de líneas
    
    while (getline(f, linea)) { // Lectura línea a línea
        
        tok.Tokenizar(linea, tokensLinea);
        numTotalPal += (int)tokensLinea.size();

        for (string& t : tokensLinea) { // Iteración sobre los tokens de la línea

            if (tipoStemmer != 0 && t.length() > 1) { // Aplicar stemmer si es necesario
                stemmer.stemmer(t, tipoStemmer);
            }

            if (!t.empty() && stopWords.find(t) == stopWords.end()) { // Si no es stop word
                numPalSinParada++;
                palabrasDiferentesDoc.insert(t);

                InformacionTermino& infoT = indice[t]; // Acceso al término del índice
                auto [itTermDoc, inserted] = infoT.getLDocs().try_emplace(idAsignado); // Intento de insercción
                
                // Actualización de frecuencias
                infoT.addFtc(); 
                itTermDoc->second.addFt();

                if (almacenarPosTerm) { // Si se almacenan posiciones, añadir la posición actual
                    itTermDoc->second.addPosTerm(posActual);
                }
            }
            posActual++;
        }
    }
    f.close();

    // Guardar información del documento
    InfDoc inf(idAsignado, numTotalPal, numPalSinParada, (int)palabrasDiferentesDoc.size(), (int)tamBytes, Fecha(ctime));
    for (const string& term : palabrasDiferentesDoc) { // Añadir términos al documento
        inf.addTerminoEnDoc(term);
    }
    indiceDocs[nomDoc] = inf;

    // Actualizar Variables Globales
    informacionColeccionDocs.setNumDocs((int)indiceDocs.size());
    informacionColeccionDocs.setNumTotalPal(informacionColeccionDocs.getNumTotalPal() + numTotalPal);
    informacionColeccionDocs.setNumTotalPalSinParada(informacionColeccionDocs.getNumTotalPalSinParada() + numPalSinParada);
    informacionColeccionDocs.setNumTotalPalDiferentes((int)indice.size());
    informacionColeccionDocs.setTamBytes(informacionColeccionDocs.getTamBytes() + (int)tamBytes);

    return true;
}

bool IndexadorHash::Indexar(const string& ficheroDocumentos) {
    ifstream f(ficheroDocumentos);
    if (!f.is_open()) { // Si no se puede abrir el fichero
        cerr << "ERROR: No se pudo abrir el fichero de lista de documentos: "
             << ficheroDocumentos << endl;
        return false;
    }

    string nomDoc;
    nomDoc.reserve(512); // reserva de memoria

    try {
        while (getline(f, nomDoc)) { // Leer linea a linea 
            if (nomDoc.empty()) continue;
            if (!IndexarDoc(nomDoc)) { // Indexar cada documento
                f.close();
                return false;
            }
        }
    } catch (const std::bad_alloc&) { // Si falta memoria durante la indexación
        cerr << "ERROR: Falta de memoria indexando: " << nomDoc << endl;
        f.close();
        return false;
    } catch (...) { // Cualquier otro error inesperado durante la indexación
        cerr << "ERROR: Error inesperado durante la indexación." << endl;
        f.close();
        return false;
    }

    f.close();
    return true;
}

bool IndexadorHash::IndexarDirectorio(const string& dirAIndexar) {
    if (!std::filesystem::exists(dirAIndexar) || !std::filesystem::is_directory(dirAIndexar)) { // Si el directorio no existe o no es un directorio
        //cerr << "ERROR: El directorio no existe o no es válido: " << dirAIndexar << endl;
        return false;
    }

    vector<string> archivos;
    string documentoActual;

    documentoActual.reserve(512); // Reserva de memoria 
    try {

        for (const auto& entrada : std::filesystem::recursive_directory_iterator(dirAIndexar)) { // Iteración recursiva
            if (std::filesystem::is_regular_file(entrada.path())) { // Si es un archivo
                archivos.push_back(entrada.path().string());
            }
        }

        std::sort(archivos.begin(), archivos.end()); // Ordenación de archivos

        for (const string& rutaDoc : archivos) { // Indexación de cada documento
            if (!IndexarDoc(rutaDoc)) {
                return false;
            }
        }
        return true;
    } catch (const std::filesystem::filesystem_error& e) {
        cerr << "ERROR: Sistema de ficheros: " << e.what() << endl;
        return false;
    } catch (const std::bad_alloc&) {
        cerr << "ERROR: Falta de memoria indexando: " << documentoActual << endl;
        return false;
    } catch (...) {
        cerr << "ERROR: Error inesperado en IndexarDirectorio." << endl;
        return false;
    }
}

bool IndexadorHash::GuardarIndexacion() const {
    try {
        if (!directorioIndice.empty() && !std::filesystem::exists(directorioIndice)) { // Si el directorio de índice no existe, intentar crearlo
            std::filesystem::create_directories(directorioIndice);
        }
    } catch (...) {
        cerr << "ERROR: No se pudo crear el directorio: " << directorioIndice << endl;
        return false;
    }

    string path = (directorioIndice.empty() ? "./" : directorioIndice + "/");

    // Apertura de ficheros para escritura en modo binario
    ofstream fConfig(path + "config.bin",  ios::binary);
    ofstream fDocs  (path + "docs.bin",    ios::binary);
    ofstream fIndice(path + "indice.bin",  ios::binary);

    if (!fConfig || !fDocs || !fIndice) { // Si no se pudieron abrir los ficheros
        cerr << "ERROR: No se pudieron abrir los ficheros de índice en: " << path << endl;
        return false;
    }

    try {
        // config.bin . Almacenamiento de configuración e información general
        fConfig.write((char*)&tipoStemmer, sizeof(int));
        fConfig.write((char*)&almacenarPosTerm, sizeof(bool));

        size_t sizeFSW = ficheroStopWords.size();
        fConfig.write((char*)&sizeFSW, sizeof(size_t));
        fConfig.write(ficheroStopWords.c_str(), sizeFSW);

        size_t nStop = stopWords.size();
        fConfig.write((char*)&nStop, sizeof(size_t));
        for (const string& sw : stopWords) {
            size_t swLen = sw.size();
            fConfig.write((char*)&swLen, sizeof(size_t));
            fConfig.write(sw.c_str(), swLen);
        }

        string delims = tok.DelimitadoresPalabra();
        size_t sizeDel = delims.size();
        fConfig.write((char*)&sizeDel, sizeof(size_t));
        fConfig.write(delims.c_str(), sizeDel);

        bool cEsp = tok.CasosEspeciales();
        bool mSin = tok.PasarAminuscSinAcentos();
        fConfig.write((char*)&cEsp, sizeof(bool));
        fConfig.write((char*)&mSin, sizeof(bool));

        int nDocCol = informacionColeccionDocs.getNumDocs();
        int nTokCol = informacionColeccionDocs.getNumTotalPal();
        int nTokSinCol = informacionColeccionDocs.getNumTotalPalSinParada();
        int nTokDifCol = informacionColeccionDocs.getNumTotalPalDiferentes();
        int nTamCol = informacionColeccionDocs.getTamBytes();
        fConfig.write((char*)&nDocCol, sizeof(int));
        fConfig.write((char*)&nTokCol, sizeof(int));
        fConfig.write((char*)&nTokSinCol, sizeof(int));
        fConfig.write((char*)&nTokDifCol, sizeof(int));
        fConfig.write((char*)&nTamCol, sizeof(int));

        size_t sizePreg = pregunta.size();
        fConfig.write((char*)&sizePreg, sizeof(size_t));
        fConfig.write(pregunta.c_str(), sizePreg);

        int nTotalP = infPregunta.getNumTotalPal();
        int nSinParadaP = infPregunta.getNumTotalPalSinParada();
        int nDifP = infPregunta.getNumTotalPalDiferentes();
        fConfig.write((char*)&nTotalP, sizeof(int));
        fConfig.write((char*)&nSinParadaP, sizeof(int));
        fConfig.write((char*)&nDifP, sizeof(int));

        // B. docs.bin . Información de cada documento indexado
        size_t nDocsMap = indiceDocs.size();
        fDocs.write((char*)&nDocsMap, sizeof(size_t));

        for (const auto& [nombre, info] : indiceDocs) {
            size_t nSize = nombre.size();
            fDocs.write((char*)&nSize, sizeof(size_t));
            fDocs.write(nombre.c_str(), nSize);

            int id = info.getIdDoc();
            int numPal = info.getNumPal();
            int numPalSin = info.getNumPalSinParada();
            int numPalDif = info.getNumPalDiferentes();
            int tam = info.getTamBytes();
            time_t fecha = info.getFechaModificacion().getTiempo();
            fDocs.write((char*)&id, sizeof(int));
            fDocs.write((char*)&numPal, sizeof(int));
            fDocs.write((char*)&numPalSin, sizeof(int));
            fDocs.write((char*)&numPalDif, sizeof(int));
            fDocs.write((char*)&tam, sizeof(int));
            fDocs.write((char*)&fecha, sizeof(time_t));

            const auto& termsSet = info.getTerminosEnDoc();
            size_t nTerms = termsSet.size();
            fDocs.write((char*)&nTerms, sizeof(size_t));
            for (const string& term : termsSet) {
                size_t tLen = term.size();
                fDocs.write((char*)&tLen, sizeof(size_t));
                fDocs.write(term.c_str(), tLen);
            }
        }

        // C. indice.bin . Almacenamiento indice principal e índice de la pregunta
        size_t nTerminos = indice.size();
        fIndice.write((char*)&nTerminos, sizeof(size_t));

        for (const auto& [word, infoT] : indice) {
            size_t wSize = word.size();
            fIndice.write((char*)&wSize, sizeof(size_t));
            fIndice.write(word.c_str(), wSize);

            int ftc = infoT.getFtc();
            fIndice.write((char*)&ftc, sizeof(int));

            const auto& l_docs = infoT.getLDocs_const();
            size_t nLD = l_docs.size();
            fIndice.write((char*)&nLD, sizeof(size_t));

            for (const auto& [idD, itd] : l_docs) {
                fIndice.write((char*)&idD, sizeof(int));
                int ft = itd.getFt();
                fIndice.write((char*)&ft, sizeof(int));

                const vector<int>& pos = itd.getPosTerm_const();
                size_t nPos = pos.size();
                fIndice.write((char*)&nPos, sizeof(size_t));
                for (int p : pos) fIndice.write((char*)&p, sizeof(int));
            }
        }

        size_t nTermPreg = indicePregunta.size();
        fIndice.write((char*)&nTermPreg, sizeof(size_t));

        for (const auto& [word, itp] : indicePregunta) {
            size_t wSize = word.size();
            fIndice.write((char*)&wSize, sizeof(size_t));
            fIndice.write(word.c_str(), wSize);

            int ft = itp.getFt();
            fIndice.write((char*)&ft, sizeof(int));

            const vector<int>& pos = itp.getPosTerm();
            size_t nPos = pos.size();
            fIndice.write((char*)&nPos, sizeof(size_t));
            for (int p : pos) fIndice.write((char*)&p, sizeof(int));
        }

        return true;

    } catch (...) {
        cerr << "ERROR: Error inesperado al guardar la indexación." << endl;
        return false;
    }
}

bool IndexadorHash::RecuperarIndexacion(const string& directorioIndexacion) {
    // Vaciar variables actuales
    indice.clear();
    indiceDocs.clear();
    informacionColeccionDocs = InfColeccionDocs();
    stopWords.clear();
    indicePregunta.clear();
    infPregunta = InformacionPregunta();
    pregunta    = "";

    string path = (directorioIndexacion.empty() ? "./" : directorioIndexacion + "/"); 

    // Apertura de ficheros para lectura en modo binario
    ifstream fConfig(path + "config.bin",  ios::binary);
    ifstream fDocs  (path + "docs.bin",    ios::binary);
    ifstream fIndice(path + "indice.bin",  ios::binary);

    if (!fConfig || !fDocs || !fIndice) { // Si no se pudieron abrir los ficheros
        cerr << "ERROR: No se encontraron los ficheros de indexación en: "
             << directorioIndexacion << endl;
        return false;
    }

    try {
        // A. config.bin
        fConfig.read((char*)&tipoStemmer,      sizeof(int));
        fConfig.read((char*)&almacenarPosTerm,  sizeof(bool));

        size_t sizeFSW;
        fConfig.read((char*)&sizeFSW, sizeof(size_t));
        ficheroStopWords.resize(sizeFSW);
        fConfig.read(&ficheroStopWords[0], sizeFSW);

        size_t nStop;
        fConfig.read((char*)&nStop, sizeof(size_t));
        stopWords.reserve(nStop);
        for (size_t i = 0; i < nStop; ++i) {
            size_t swLen;
            fConfig.read((char*)&swLen, sizeof(size_t));
            string sw(swLen, ' ');
            fConfig.read(&sw[0], swLen);
            stopWords.insert(move(sw));
        }

        size_t sizeDel;
        fConfig.read((char*)&sizeDel, sizeof(size_t));
        string delims(sizeDel, ' ');
        fConfig.read(&delims[0], sizeDel);

        bool cEsp, mSin;
        fConfig.read((char*)&cEsp, sizeof(bool));
        fConfig.read((char*)&mSin, sizeof(bool));
        tok.DelimitadoresPalabra(delims);
        tok.CasosEspeciales(cEsp);
        tok.PasarAminuscSinAcentos(mSin);

        int nDocCol, nTokCol, nTokSinCol, nTokDifCol, nTamCol;
        fConfig.read((char*)&nDocCol, sizeof(int));
        fConfig.read((char*)&nTokCol, sizeof(int));
        fConfig.read((char*)&nTokSinCol, sizeof(int));
        fConfig.read((char*)&nTokDifCol, sizeof(int));
        fConfig.read((char*)&nTamCol, sizeof(int));
        informacionColeccionDocs = InfColeccionDocs(nDocCol, nTokCol, nTokSinCol, nTokDifCol, nTamCol);

        size_t sizePreg;
        fConfig.read((char*)&sizePreg, sizeof(size_t));
        pregunta.resize(sizePreg);
        fConfig.read(&pregunta[0], sizePreg);

        int nTotalP, nSinParadaP, nDifP;
        fConfig.read((char*)&nTotalP, sizeof(int));
        fConfig.read((char*)&nSinParadaP, sizeof(int));
        fConfig.read((char*)&nDifP, sizeof(int));
        infPregunta = InformacionPregunta(nTotalP, nSinParadaP, nDifP);

        // B. docs.bin
        size_t nDocsMap;
        fDocs.read((char*)&nDocsMap, sizeof(size_t));
        indiceDocs.reserve(nDocsMap);

        for (size_t i = 0; i < nDocsMap; ++i) {
            size_t nSize;
            fDocs.read((char*)&nSize, sizeof(size_t));
            string nombre(nSize, ' ');
            fDocs.read(&nombre[0], nSize);

            int id, numPal, numPalSin, numPalDif, tam;
            time_t fecha;
            fDocs.read((char*)&id, sizeof(int));
            fDocs.read((char*)&numPal, sizeof(int));
            fDocs.read((char*)&numPalSin, sizeof(int));
            fDocs.read((char*)&numPalDif, sizeof(int));
            fDocs.read((char*)&tam, sizeof(int));
            fDocs.read((char*)&fecha, sizeof(time_t));

            InfDoc info(id, numPal, numPalSin, numPalDif, tam, Fecha(fecha));

            size_t nTerms;
            fDocs.read((char*)&nTerms, sizeof(size_t));
            for (size_t j = 0; j < nTerms; ++j) {
                size_t tLen;
                fDocs.read((char*)&tLen, sizeof(size_t));
                string term(tLen, ' ');
                fDocs.read(&term[0], tLen);
                info.addTerminoEnDoc(term);
            }

            indiceDocs.insert({move(nombre), move(info)});
        }

        // C. indice.bin 
        size_t nTerminos;
        fIndice.read((char*)&nTerminos, sizeof(size_t));
        indice.reserve(nTerminos);

        for (size_t i = 0; i < nTerminos; ++i) {
            size_t wSize;
            fIndice.read((char*)&wSize, sizeof(size_t));
            string word(wSize, ' ');
            fIndice.read(&word[0], wSize);

            int ftc;
            fIndice.read((char*)&ftc, sizeof(int));

            InformacionTermino infoT;
            infoT.setFtc(ftc);

            size_t nLD;
            fIndice.read((char*)&nLD, sizeof(size_t));
            infoT.getLDocs().reserve(nLD);

            for (size_t j = 0; j < nLD; ++j) {
                int idD, ft;
                fIndice.read((char*)&idD, sizeof(int));
                fIndice.read((char*)&ft,  sizeof(int));

                InfTermDoc itd;
                itd.setFt(ft);

                size_t nPos;
                fIndice.read((char*)&nPos, sizeof(size_t));
                itd.getPosTerm().reserve(nPos);
                for (size_t k = 0; k < nPos; ++k) {
                    int p;
                    fIndice.read((char*)&p, sizeof(int));
                    itd.addPosTerm(p);
                }
                infoT.getLDocs().insert({idD, move(itd)});
            }
            indice.insert({move(word), move(infoT)});
        }

        size_t nTermPreg;
        fIndice.read((char*)&nTermPreg, sizeof(size_t));

        for (size_t i = 0; i < nTermPreg; ++i) {
            size_t wSize;
            fIndice.read((char*)&wSize, sizeof(size_t));
            string word(wSize, ' ');
            fIndice.read(&word[0], wSize);

            int ft;
            fIndice.read((char*)&ft, sizeof(int));

            InformacionTerminoPregunta itp;
            itp.setFt(ft);

            size_t nPos;
            fIndice.read((char*)&nPos, sizeof(size_t));
            itp.getPosTerm().reserve(nPos);
            for (size_t k = 0; k < nPos; ++k) {
                int p;
                fIndice.read((char*)&p, sizeof(int));
                itp.addPosTerm(p);
            }
            indicePregunta.insert({move(word), move(itp)});
        }

        directorioIndice = directorioIndexacion;
        return true;

    } catch (...) {
        indice.clear();
        indiceDocs.clear();
        informacionColeccionDocs = InfColeccionDocs();
        stopWords.clear();
        indicePregunta.clear();
        infPregunta = InformacionPregunta();
        pregunta    = "";
        cerr << "ERROR: Fallo al recuperar indexación desde: " << directorioIndexacion << endl;
        return false;
    }
}

bool IndexadorHash::IndexarPregunta(const string& preg) {
    indicePregunta.clear();
    infPregunta = InformacionPregunta();
    pregunta    = preg;

    list<string> tokens;
    tok.Tokenizar(preg, tokens);

    if (tokens.empty()) {
        cerr << "ERROR: La pregunta no contiene ningún término." << endl;
        return false;
    }

    int totalPal    = (int)tokens.size();
    int palSinParada = 0;
    int posActual   = 0;

    for (string& t : tokens) {

        if (tipoStemmer != 0 && t.length() > 1) { // Si hay que aplicar stemmer y t tiene más de un carácter
            stemmer.stemmer(t, tipoStemmer);
        }

        if (stopWords.find(t) == stopWords.end()) { // Si no es stop word
            // Aplicar stemmer
            

            palSinParada++;
            InformacionTerminoPregunta& itp = indicePregunta[t]; // Acceso al término de la pregunta
            itp.addFt(); // Incremento de frecuencia
            if (almacenarPosTerm) {
                itp.addPosTerm(posActual);
            }
        }
        posActual++;
    }

    if (indicePregunta.empty()) {
        cerr << "ERROR: La pregunta solo contiene palabras de parada." << endl;
        return false;
    }

    // Actualización de información de la pregunta
    infPregunta.setNumTotalPal(totalPal);
    infPregunta.setNumTotalPalSinParada(palSinParada);
    infPregunta.setNumTotalPalDiferentes((int)indicePregunta.size());

    return true;
}

bool IndexadorHash::DevuelvePregunta(string& preg) const {
    if (!indicePregunta.empty()) {
        preg = pregunta;
        return true;
    }
    preg = "";
    return false;
}

bool IndexadorHash::DevuelvePregunta(const string& word, InformacionTerminoPregunta& inf) const {
    string aux = word;
    if (normalizarPalabra(aux)) {
        auto it = indicePregunta.find(aux);
        if (it != indicePregunta.end()) {
            inf = it->second;
            return true;
        }
    }
    inf = InformacionTerminoPregunta();
    return false;
}

bool IndexadorHash::DevuelvePregunta(InformacionPregunta& inf) const {
    if (!infPregunta.isEmpty()) {
        inf = infPregunta;
        return true;
    }
    inf = InformacionPregunta();
    return false;
}

bool IndexadorHash::Devuelve(const string& word, InformacionTermino& inf) const {
    string aux = word;
    if (normalizarPalabra(aux)) {
        auto it = indice.find(aux);
        if (it != indice.end()) {
            inf = it->second;
            return true;
        }
    }
    inf = InformacionTermino();
    return false;
}

bool IndexadorHash::Devuelve(const string& word, const string& nomDoc, InfTermDoc& InfDocOut) const {
    string aux = word;
    if (normalizarPalabra(aux)) {
        auto itTerm = indice.find(aux);
        auto itDoc  = indiceDocs.find(nomDoc);

        if (itTerm != indice.end() && itDoc != indiceDocs.end()) {
            const auto& l_docs = itTerm->second.getLDocs_const();
            auto itDocEnTerm = l_docs.find(itDoc->second.getIdDoc());
            if (itDocEnTerm != l_docs.end()) {
                InfDocOut = itDocEnTerm->second;
                return true;
            }
        }
    }
    InfDocOut = InfTermDoc();
    return false;
}

bool IndexadorHash::Existe(const string& word) const {
    string aux = word;
    if (normalizarPalabra(aux)) {
        return indice.find(aux) != indice.end();
    }
    return false;
}

bool IndexadorHash::BorraDoc(const string& nomDoc) {
    auto itDoc = indiceDocs.find(nomDoc);
    if (itDoc == indiceDocs.end()){ // Si el docuemnto no está indexado
        return false;
    }

    InfDoc& docRef = itDoc->second;
    int idABorrar = docRef.getIdDoc();

    // Recorrer solo los términos que el documento contiene
    for (const string& termino : docRef.getTerminosEnDoc()) {
        auto itTerm = indice.find(termino);
        if (itTerm == indice.end()) continue;

        InformacionTermino& infTerm = itTerm->second;
        auto& l_docs = infTerm.getLDocs();
        auto  itDocEnTerm = l_docs.find(idABorrar);
        if (itDocEnTerm == l_docs.end()) continue;

        // Restar la frecuencia de este documento de la frecuencia total del término
        infTerm.setFtc(infTerm.getFtc() - itDocEnTerm->second.getFt());
        l_docs.erase(itDocEnTerm);

        // Si el término ya no aparece en ningún documento, eliminarlo del índice
        if (l_docs.empty()) {
            indice.erase(itTerm);
        }
    }

    // Actualizar la información general
    informacionColeccionDocs.setNumTotalPal(informacionColeccionDocs.getNumTotalPal() - docRef.getNumPal());
    informacionColeccionDocs.setNumTotalPalSinParada(informacionColeccionDocs.getNumTotalPalSinParada() - docRef.getNumPalSinParada());
    informacionColeccionDocs.setTamBytes(informacionColeccionDocs.getTamBytes() - docRef.getTamBytes());

    // Eliminar el documento
    indiceDocs.erase(itDoc);

    // Actualizar el número de documentos y el número total de palabras diferentes en la colección
    informacionColeccionDocs.setNumDocs((int)indiceDocs.size());
    informacionColeccionDocs.setNumTotalPalDiferentes((int)indice.size()); // <--- ESTO SOLUCIONA EL TEST

    return true;
}

void IndexadorHash::VaciarIndiceDocs() {
    indice.clear();
    indiceDocs.clear();
    informacionColeccionDocs = InfColeccionDocs();
}

void IndexadorHash::VaciarIndicePreg() {
    indicePregunta.clear();
    infPregunta = InformacionPregunta();
    pregunta    = "";
}

int IndexadorHash::NumPalIndexadas() const {
    return (int)indice.size();
}

string IndexadorHash::DevolverFichPalParada() const {
    return ficheroStopWords;
}

void IndexadorHash::ListarPalParada() const {
    ifstream f(ficheroStopWords);
    if (!f.is_open()) {
        cerr << "ERROR: No se pudo abrir el fichero de stop words para listar: " << ficheroStopWords << endl;
        return;
    }
    string linea;
    linea.reserve(256); // Reserva de memoria para lectura de líneas
    while (getline(f, linea)) {
        if (!linea.empty()) {
            cout << linea << endl;
        }
    }
    f.close();
    /*for (const string& sw : stopWordsVector) {
        cout << sw << endl;
    }*/
}

int IndexadorHash::NumPalParada() const {
    return (int)stopWords.size();
}

string IndexadorHash::DevolverDelimitadores() const {
    return tok.DelimitadoresPalabra();
}

bool IndexadorHash::DevolverCasosEspeciales() const {
    return tok.CasosEspeciales();
}

bool IndexadorHash::DevolverPasarAminuscSinAcentos() const {
    return tok.PasarAminuscSinAcentos();
}

bool IndexadorHash::DevolverAlmacenarPosTerm() const {
    return almacenarPosTerm;
}

string IndexadorHash::DevolverDirIndice() const {
    return directorioIndice;
}

int IndexadorHash::DevolverTipoStemming() const {
    return tipoStemmer;
}

void IndexadorHash::ListarInfColeccDocs() const {
    cout << informacionColeccionDocs << endl;
}

void IndexadorHash::ListarTerminos() const {
    for (const auto& [term, info] : indice) {
        cout << term << '\t' << info << endl;
    }
}

bool IndexadorHash::ListarTerminos(const string& nomDoc) const {
    auto itDoc = indiceDocs.find(nomDoc);
    if (itDoc == indiceDocs.end()) return false;

    // Usamos terminosEnDoc para iterar solo los términos del documento (eficiente)
    for (const string& termino : itDoc->second.getTerminosEnDoc()) {
        auto itTerm = indice.find(termino);
        if (itTerm != indice.end()) {
            cout << termino << '\t' << itTerm->second << endl;
        }
    }
    return true;
}

void IndexadorHash::ListarDocs() const {
    for (const auto& [nombre, info] : indiceDocs) {
        cout << nombre << '\t' << info << endl;
    }
}

bool IndexadorHash::ListarDocs(const string& nomDoc) const {
    auto it = indiceDocs.find(nomDoc);
    if (it == indiceDocs.end()) return false;
    cout << nomDoc << '\t' << it->second << endl;
    return true;
}
